# jenkins-static-try
Jenkis-static
